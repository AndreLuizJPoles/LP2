﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pMenus
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void btnRemove1_Click(object sender, EventArgs e)
        {
            Random randNum = new Random();

            if(!(Int32.TryParse(txtNumero1.Text, out int Num1) && Int32.TryParse(txtNumero2.Text, out int Num2)))
            {
                MessageBox.Show("Digite um valor válido");
            }
            else 
            {
                if (Num1 <= Num2)
                {
                    int aleatorio = randNum.Next(Num1, Num2);

                    MessageBox.Show("Seu número é " + aleatorio);
                }
                else
                {
                    MessageBox.Show("O Número 1 deve ser menor que o Número 2");
                }
            }
            
        }
    }
}
