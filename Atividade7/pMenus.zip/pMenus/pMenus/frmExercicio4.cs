﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pMenus
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnNumeros_Click(object sender, EventArgs e)
        {
            int cont=0;

            for(var i=0; i<rtxtTexto.Text.Length;i++)
            {
                if (Char.IsNumber(rtxtTexto.Text, i))
                {
                    cont++;
                }
            }

            MessageBox.Show("Há " + cont + " números nesse texto");
        }

        private void btnBranco_Click(object sender, EventArgs e)
        {
            int posicao = -1, i = 0;
            
            while(i < rtxtTexto.Text.Length)
            {
                if (Char.IsWhiteSpace(rtxtTexto.Text[i]))
                {
                    posicao = i;
                    break;
                }

                i++;
            }

            if (posicao >= 0)
                MessageBox.Show("A posição do primeiro espaço em branco é " + posicao);
            else
                MessageBox.Show("Não há espaços em branco");
        }

        private void btnLetras_Click(object sender, EventArgs e)
        {
            int cont = 0, letras = 0;
            foreach(char letra in rtxtTexto.Text)
            {
                if (Char.IsLetter(rtxtTexto.Text, cont))
                {
                    letras++;
                }
                cont++;
            }
            MessageBox.Show("Há " + letras + " letras nesse texto");
        }
    }
}
