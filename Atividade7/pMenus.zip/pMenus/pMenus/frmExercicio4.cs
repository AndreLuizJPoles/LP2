﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pMenus
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnNumeros_Click(object sender, EventArgs e)
        {
            int cont=0;

            for(var i=0; i<rtxtTexto.Text.Length;i++)
            {
                if (Char.IsDigit(rtxtTexto.Text, i))
                {
                    cont++;
                }
            }

            MessageBox.Show("Há " + cont + " números nesse texto");
        }

        private void btnBranco_Click(object sender, EventArgs e)
        {
            int posicao = 0;
            posicao = rtxtTexto.Text.IndexOf(" ");

            if (posicao >= 0)
                MessageBox.Show("A posição do primeiro espaço em branco é " + posicao);
            else
                MessageBox.Show("Não há espaços em branco");
        }

        private void btnLetras_Click(object sender, EventArgs e)
        {
            int cont = 0;
            foreach(char letra in rtxtTexto.Text)
            {
                cont++;
            }
            MessageBox.Show("Há " + cont + " letras nesse texto");
        }
    }
}
