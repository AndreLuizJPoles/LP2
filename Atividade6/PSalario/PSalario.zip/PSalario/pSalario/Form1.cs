﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pSalario
{
    public partial class lbl_salarioBruto : Form
    {
        public lbl_salarioBruto()
        {
            InitializeComponent();
        }

        private void btnValidarDesconto_Click(object sender, EventArgs e)
        {
            double salarioBruto, numeroFilhos, descontoINSS, descontoIRPF, salarioLiquido, salarioFamilia;

            if (txtNome.Text == string.Empty)
            {
                MessageBox.Show("Insira o seu nome!!!");
            }
            else
            if(!double.TryParse(mskbxSalarioBruto.Text, out salarioBruto)||!double.TryParse(cbxNumeroFilhos.Text, out numeroFilhos))
            {
                MessageBox.Show("Dados inválidos!");
            }
            else
            {
                if (salarioBruto <= 800.47)
                {
                    txtAliquotaINSS.Text = "7,65%";
                    descontoINSS = 0.0765 * salarioBruto;
                }
                else if (salarioBruto<=1050)
                {
                    txtAliquotaINSS.Text = "8,65%";
                    descontoINSS = 0.0865 * salarioBruto;
                }
                else if (salarioBruto<=1400.77)
                {
                    txtAliquotaINSS.Text = "9%";
                    descontoINSS = 0.09 * salarioBruto;
                }
                else if (salarioBruto<=2801.56)
                {
                    txtAliquotaINSS.Text = "11%";
                    descontoINSS = 0.11 * salarioBruto;
                }
                else
                {
                    txtAliquotaINSS.Text = "Teto";
                    descontoINSS = 308.17;
                }

                if(salarioBruto<=1257.12)
                {
                    descontoIRPF = 0;
                    txtAliquotaIRPF.Text = "Isento";
                }
                else if (salarioBruto <= 2512.08)
                {
                    descontoIRPF = salarioBruto * 0.15;
                    txtAliquotaIRPF.Text = "15%";
                }
                else
                {
                    descontoIRPF = salarioBruto * 0.275;
                    txtAliquotaIRPF.Text = "27,5%";
                }
                txtDescontoINSS.Text = descontoINSS.ToString("N2");
                txtDescontoIRPF.Text = descontoIRPF.ToString("N2");

                if(salarioBruto<=435.52)
                {
                    salarioFamilia = 22.33 * numeroFilhos;
                }
                else if(salarioBruto<=654.61)
                {
                    salarioFamilia = 15.74 * numeroFilhos;
                }
                else
                {
                    salarioFamilia = 0;
                }

                txtSalarioFamilia.Text = salarioFamilia.ToString("N2");

                salarioLiquido = salarioBruto + salarioFamilia - descontoINSS - descontoIRPF;
                txtSalarioLiquido.Text = salarioLiquido.ToString("N2");

                if(rbtnMasculino.Checked)
                {
                    if (cbxCasado.Checked)
                    {
                        lblDados.Text = ("Os descontos do salário do Sr " + txtNome.Text + " que é casado e tem " + cbxNumeroFilhos.Text + " filho(s)");
                    }
                    else
                    {
                        lblDados.Text = ("Os descontos do salário do Sr " + txtNome.Text + " que é solteiro e tem " + cbxNumeroFilhos.Text + " filho(s)");
                    }
                }
                else
                {
                    if (cbxCasado.Checked)
                    {
                        lblDados.Text = ("Os descontos do salário da Sra " + txtNome.Text + " que é casada e tem " + cbxNumeroFilhos.Text + " filho(s)");
                    }
                    else
                    {
                        lblDados.Text = ("Os descontos do salário da Sra " + txtNome.Text + " que é solteira e tem " + cbxNumeroFilhos.Text + " filho(s)");
                    }
                }
            }
            
        }
    }
}
