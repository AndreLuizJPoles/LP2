﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PVendas
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            double[,] lista = new double[5, 4];
            string auxiliar="";
            double [] SomaSemana = new double [5];
            double total = 0;

            for (var mes = 0; mes < 5; mes++) 
            {
                for (var semana = 0; semana < 4; semana++)
                {
                    auxiliar = Interaction.InputBox("Digite o valor da semana " + (semana + 1) + " do mês " + (mes + 1), "Entrada dos dados");
                    if(!(double.TryParse(auxiliar, out lista[mes, semana])))
                    {
                        MessageBox.Show("Digite um valor válido");
                        semana--;
                    }
                    else 
                    {
                        if(!(lista[mes,semana] >= 0))
                        {
                            MessageBox.Show("Digite apenas valores positivos");
                            semana--;
                        }
                        else
                        {
                            lbxVendas.Items.Add("Total do mes: " + (mes + 1) + " Semana: " + (semana + 1) + " " + (lista[mes, semana].ToString("N2")));
                        }
                    }

                    

                }
                SomaSemana[mes] = lista[mes, 0] + lista[mes, 1] + lista[mes, 2] + lista[mes, 3];
                lbxVendas.Items.Add(">> Total Mês: " + SomaSemana[mes].ToString("N2"));
                lbxVendas.Items.Add("---------------------------------------------------------");
            }

            total = SomaSemana[0] + SomaSemana[1] + SomaSemana[2] + SomaSemana[3] + SomaSemana[4];
            lbxVendas.Items.Add(">> Total Geral: " + total.ToString("N2"));

        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
