﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pCalculadora
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtNum1.Clear();
            txtNum2.Clear();
            txtResultado.Clear();


        }

        private void btnSoma_Click(object sender, EventArgs e)
        {
            Double Num1, Num2, resultado;

            if(Double.TryParse(txtNum1.Text, out Num1) && Double.TryParse(txtNum2.Text, out Num2))
            {
                resultado = Num1 + Num2;
                txtResultado.Text = resultado.ToString("N");
            }
            else
            {
                MessageBox.Show("Insira apenas números");
                txtNum1.Focus();
            }

        }

        private void btnSub_Click(object sender, EventArgs e)
        {
            Double Num1, Num2, resultado;

            if (Double.TryParse(txtNum1.Text, out Num1) && Double.TryParse(txtNum2.Text, out Num2))
            {
                resultado = Num1 - Num2;
                txtResultado.Text = resultado.ToString("N");
            }
            else
            {
                MessageBox.Show("Insira apenas números");
                txtNum1.Focus();
            }
        }

        private void btnMult_Click(object sender, EventArgs e)
        {
            Double Num1, Num2, resultado;

            if (Double.TryParse(txtNum1.Text, out Num1) && Double.TryParse(txtNum2.Text, out Num2))
            {
                resultado = Num1 * Num2;
                txtResultado.Text = resultado.ToString("N");
            }
            else
            {
                MessageBox.Show("Insira apenas números");
                txtNum1.Focus();
            }
        }

        private void btnDiv_Click(object sender, EventArgs e)
        {
            Double Num1, Num2, resultado;

            if (Double.TryParse(txtNum1.Text, out Num1) && Double.TryParse(txtNum2.Text, out Num2))
            {
                if (Num2 != 0)
                {
                    resultado = Num1 / Num2;
                    txtResultado.Text = resultado.ToString("N");
                }
                else
                {
                    MessageBox.Show("Insira um divisor diferente de zero");
                    txtNum2.Focus();
                }
            }
            else
            {
                MessageBox.Show("Insira apenas números");
                txtNum1.Focus();
            }
        }
    }
}
