﻿namespace PAtividade9
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnItem1 = new System.Windows.Forms.Button();
            this.btnItem2 = new System.Windows.Forms.Button();
            this.btnItem3 = new System.Windows.Forms.Button();
            this.btnItem4 = new System.Windows.Forms.Button();
            this.btnItem5 = new System.Windows.Forms.Button();
            this.btnItem6 = new System.Windows.Forms.Button();
            this.lbxNomes = new System.Windows.Forms.ListBox();
            this.lblLista = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnItem1
            // 
            this.btnItem1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnItem1.Location = new System.Drawing.Point(61, 131);
            this.btnItem1.Margin = new System.Windows.Forms.Padding(4);
            this.btnItem1.Name = "btnItem1";
            this.btnItem1.Size = new System.Drawing.Size(235, 101);
            this.btnItem1.TabIndex = 0;
            this.btnItem1.Text = "Ler 20 números e inverter";
            this.btnItem1.UseVisualStyleBackColor = true;
            this.btnItem1.Click += new System.EventHandler(this.btnItem1_Click);
            // 
            // btnItem2
            // 
            this.btnItem2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnItem2.Location = new System.Drawing.Point(340, 131);
            this.btnItem2.Margin = new System.Windows.Forms.Padding(4);
            this.btnItem2.Name = "btnItem2";
            this.btnItem2.Size = new System.Drawing.Size(235, 101);
            this.btnItem2.TabIndex = 1;
            this.btnItem2.Text = "Ler Quant. e Preço Mercadorias";
            this.btnItem2.UseVisualStyleBackColor = true;
            this.btnItem2.Click += new System.EventHandler(this.btnItem2_Click);
            // 
            // btnItem3
            // 
            this.btnItem3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnItem3.Location = new System.Drawing.Point(635, 131);
            this.btnItem3.Margin = new System.Windows.Forms.Padding(4);
            this.btnItem3.Name = "btnItem3";
            this.btnItem3.Size = new System.Drawing.Size(235, 101);
            this.btnItem3.TabIndex = 2;
            this.btnItem3.Text = "Variável Total";
            this.btnItem3.UseVisualStyleBackColor = true;
            this.btnItem3.Click += new System.EventHandler(this.btnItem3_Click);
            // 
            // btnItem4
            // 
            this.btnItem4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnItem4.Location = new System.Drawing.Point(61, 281);
            this.btnItem4.Margin = new System.Windows.Forms.Padding(4);
            this.btnItem4.Name = "btnItem4";
            this.btnItem4.Size = new System.Drawing.Size(235, 101);
            this.btnItem4.TabIndex = 3;
            this.btnItem4.Text = "ArrayList";
            this.btnItem4.UseVisualStyleBackColor = true;
            this.btnItem4.Click += new System.EventHandler(this.btnItem4_Click);
            // 
            // btnItem5
            // 
            this.btnItem5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnItem5.Location = new System.Drawing.Point(340, 281);
            this.btnItem5.Margin = new System.Windows.Forms.Padding(4);
            this.btnItem5.Name = "btnItem5";
            this.btnItem5.Size = new System.Drawing.Size(235, 101);
            this.btnItem5.TabIndex = 4;
            this.btnItem5.Text = "Média Aluno";
            this.btnItem5.UseVisualStyleBackColor = true;
            this.btnItem5.Click += new System.EventHandler(this.btnItem5_Click);
            // 
            // btnItem6
            // 
            this.btnItem6.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnItem6.Location = new System.Drawing.Point(635, 281);
            this.btnItem6.Margin = new System.Windows.Forms.Padding(4);
            this.btnItem6.Name = "btnItem6";
            this.btnItem6.Size = new System.Drawing.Size(235, 101);
            this.btnItem6.TabIndex = 5;
            this.btnItem6.Text = "Nomes Pessoas";
            this.btnItem6.UseVisualStyleBackColor = true;
            this.btnItem6.Click += new System.EventHandler(this.btnItem6_Click);
            // 
            // lbxNomes
            // 
            this.lbxNomes.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbxNomes.FormattingEnabled = true;
            this.lbxNomes.ItemHeight = 25;
            this.lbxNomes.Location = new System.Drawing.Point(933, 41);
            this.lbxNomes.Name = "lbxNomes";
            this.lbxNomes.Size = new System.Drawing.Size(459, 379);
            this.lbxNomes.TabIndex = 6;
            // 
            // lblLista
            // 
            this.lblLista.AutoSize = true;
            this.lblLista.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLista.Location = new System.Drawing.Point(1007, 9);
            this.lblLista.Name = "lblLista";
            this.lblLista.Size = new System.Drawing.Size(289, 29);
            this.lblLista.TabIndex = 7;
            this.lblLista.Text = "Lista do Nome Pessoas";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::PAtividade9.Properties.Resources.latest;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.ClientSize = new System.Drawing.Size(1413, 450);
            this.Controls.Add(this.lblLista);
            this.Controls.Add(this.lbxNomes);
            this.Controls.Add(this.btnItem6);
            this.Controls.Add(this.btnItem5);
            this.Controls.Add(this.btnItem4);
            this.Controls.Add(this.btnItem3);
            this.Controls.Add(this.btnItem2);
            this.Controls.Add(this.btnItem1);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.Text = "Atividade 9";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnItem1;
        private System.Windows.Forms.Button btnItem2;
        private System.Windows.Forms.Button btnItem3;
        private System.Windows.Forms.Button btnItem4;
        private System.Windows.Forms.Button btnItem5;
        private System.Windows.Forms.Button btnItem6;
        private System.Windows.Forms.ListBox lbxNomes;
        private System.Windows.Forms.Label lblLista;
    }
}

