﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.Collections;

namespace PAtividade9
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnItem1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string aux;
            string saida = "";

            for(int i=0;i<20;i++)
            {
                aux = Interaction.InputBox("Digite o número", "Entrada de dados");
                if(!Int32.TryParse(aux, out vetor[i]))
                {
                    MessageBox.Show("Dado inválido");
                    i--;
                }
                else
                {
                    saida = vetor[i] + "\n" + saida;
                }
            }
            MessageBox.Show(saida);
        }

        private void btnItem2_Click(object sender, EventArgs e)
        {
            double[] qtd = new double[10];
            double[] valor = new double[10];
            double faturamento=0;
            string auxiliar ="";

            for(var i=0;i<10;i++)
            {
                auxiliar = Interaction.InputBox("Digite a quantidade da mercadoria" + (i + 1), "Entrada das quantidades");
                if(!Double.TryParse(auxiliar, out qtd[i]))
                {
                    MessageBox.Show("Quantidade inválida");
                    i--;
                }
                else
                {
                    while(valor[i]<=0)
                    {
                        auxiliar = "";
                        auxiliar = Interaction.InputBox("Digite o valor da mercadoria" + (i + 1), "Entrada de valores");
                        if(!Double.TryParse(auxiliar, out valor[i]))
                        {
                            MessageBox.Show("Valor inválido");
                        }
                    }
                }
                faturamento += qtd[i] * valor[i];
            }
            MessageBox.Show("O faturamento é " + faturamento.ToString("N2"));
        }

        private void btnItem3_Click(object sender, EventArgs e)
        {
            string[] Alunos = {"Viviane", "André", "Hélio", "Denise", "Junior", "Leonardo", "Jose", "Nelma", "Tobby"};
            Int32 I, Total = 0;
            Int32 N = Alunos.Length;
            for (I = 0; I < N - 1; I++)
            {
                Total += Alunos[I].Length;
            }
            MessageBox.Show("O Total vale " + Total);
        }

        private void btnItem5_Click(object sender, EventArgs e)
        {
            double[,] notas = new double[20, 3];
            string auxiliar = "";

            for(var i=0; i<20; i++)
            {
                for(var j=0; j<3;j++)
                {
                    auxiliar = Interaction.InputBox("Digite a nota " + (j+1) + " do aluno " + (i+1), "Entrada de notas");

                    if(!Double.TryParse(auxiliar, out notas[i,j]))
                    {
                        MessageBox.Show("Nota inválida");
                        j--;
                    }
                    else
                    {
                        if(!(notas[i,j] >= 0 && notas[i,j] <= 10))
                        {
                            MessageBox.Show("Nota inválida");
                            j--;
                        }
                    }
                }
                double media = (notas[i, 0] + notas[i, 1] + notas[i, 2]) / 3;
                MessageBox.Show("Aluno " + (i+1) + ": Média: " + media.ToString("N2"));
            }
        }

        private void btnItem4_Click(object sender, EventArgs e)
        {
            ArrayList alunos = new ArrayList { "Ana", "André", "Débora", "Fátima", "João", "Janete", "Otávio", "Marcelo", "Pedro", "Thais" };
            string lista="";

            alunos.RemoveAt(6);

            for(var i=0;i<9;i++)
            {
                lista += alunos[i] + " ";
            }
            MessageBox.Show(lista);
        }

        private void btnItem6_Click(object sender, EventArgs e)
        {
            string[] nomes = new string[5];
            int[] caracteres = new int[5];
            string auxiliar = "";

            for (var i = 0; i < 5; i++)
            {
                nomes[i] = Interaction.InputBox("Digite os nomes", "Entrada dos nomes");
                auxiliar = nomes[i].Replace(" ", "");
                caracteres[i] = auxiliar.Length;

               lbxNomes.Items.Add("O nome " + nomes[i] + " tem " + caracteres[i] + " caracteres");
            }
            
        }
    }
}
